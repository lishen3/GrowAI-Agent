GrowAI 1.5.0 Web / 第三方资源说明

本目录随正式 Web 资源一起分发。Web-packages.tsv 按版本列出发布锁文件中本机已安装的生产依赖，也包括参与构建的工具。末列编号对应 Web-package-license-texts.txt 中的上游许可原文；短横线表示该包目录未提供独立文本或共用上游许可。保留这些声明、字体内嵌署名和 web/cmaps/LICENSE。

PDF.js 及 PDF Worker 采用 Apache License 2.0。168 个预编译 CMap 的 Adobe 许可单列于 PDFjs-CMaps-Adobe.txt。

Expo Vector Icons 和所含 react-native-vector-icons 的代码许可独立于字体图稿许可。以下 19 个字体文件随发布版原样分发；GrowAI 未修改字形。品牌和商标名称属于各自权利人。

AntDesign — Ant Design / Ant Financial；MIT。https://github.com/ant-design/ant-design-icons
Entypo+ — Daniel Bruce；CC BY-SA 4.0。https://www.entypo.com/ · https://github.com/chancancode/entypo-plus · https://creativecommons.org/licenses/by-sa/4.0/
EvilIcons — Alexander Madyankin、Roman Shamin；MIT。https://github.com/evil-icons/evil-icons
Feather — Cole Bemis 和贡献者；MIT。https://github.com/feathericons/feather
FontAwesome — Dave Gandy（字体内版权标注 2016），SIL Open Font License 1.1。https://fontawesome.com/v4/license/
FontAwesome5_Brands、FontAwesome5_Regular、FontAwesome5_Solid；FontAwesome6_Brands、FontAwesome6_Regular、FontAwesome6_Solid — Fonticons, Inc.；Font Awesome Free 字体为 SIL Open Font License 1.1。https://fontawesome.com/license/free
Fontisto — Kenan Gündoğan；MIT。https://github.com/kenangundogan/fontisto
Foundation — ZURB，2013；图标字体 3.0 CSS 源文件头标注 MIT。https://github.com/zurb/foundation-icon-fonts
Ionicons — Ionic；MIT。https://github.com/ionic-team/ionicons
MaterialIcons — Google, Inc.，字体内版权标注 2018；Apache License 2.0。https://github.com/google/material-design-icons
MaterialCommunityIcons — Pictogrammers 及贡献者；字体采用 Apache License 2.0，随附上游许可指引。https://github.com/Templarian/MaterialDesign
Octicons — GitHub, Inc.；随附 Octicons 上游许可。https://github.com/primer/octicons
SimpleLineIcons — Sabbir Ahmed 和贡献者；MIT。https://github.com/thesabbir/simple-line-icons
Zocial — Sam Collins、zimbatm 和贡献者；附上游 MIT 许可。https://github.com/smcllns/css-social-buttons

与字体具体作者对应的文本见本目录 Font-*.txt。Apache 2.0 全文亦见 PDFjs-Apache-2.0.txt；SIL OFL 1.1 全文见 Font-FontAwesome-Free.txt。
