"""Local launcher for the GrowAI Windows distribution."""
import argparse
from contextlib import closing
from functools import partial
from getpass import getpass
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
from pathlib import Path
import socket
import sys
import threading
import webbrowser

from dotenv import dotenv_values, set_key

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
URL = "http://localhost:8081"
BASE = "https://api.deepseek.com/v1"


def settings(path):
    if not path.is_file():
        return {}
    return dotenv_values(path, encoding="utf-8-sig", interpolate=False)


def configure():
    path = ROOT / "backend" / ".env"
    old = settings(path)
    if (old.get("LLM_BASE_URL") or BASE).rstrip("/") not in (BASE, "https://api.deepseek.com"):
        raise ValueError("此配置使用其他服务地址。请手动编辑 backend/.env，核对地址和对应密钥。")
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise ValueError("请在本地交互窗口运行 Configure-AI.cmd，以便隐藏密钥输入。")
    if old.get("LLM_API_KEY") and input("已存在密钥。需要更换请输入 YES，直接回车取消：").strip() != "YES":
        print("已取消。")
        return
    key = getpass("请粘贴自己的 DeepSeek API Key 并按回车（不会显示），直接回车取消：").strip()
    if not key:
        print("已取消。")
        return
    if not key.isascii() or not key.isprintable() or any(ch.isspace() for ch in key):
        raise ValueError("密钥格式无效，请重新配置。")
    if path.exists():
        # Normalize the BOM only while replacing the selected key; retain other settings.
        set_key(str(path), "LLM_API_KEY", key, quote_mode="always", encoding="utf-8-sig")
    else:
        # Exclusive creation protects a configuration another window may have just saved.
        with path.open("x", encoding="utf-8") as f:
            f.write(f"LLM_BASE_URL={BASE}\nLLM_MODEL=deepseek-v4-pro\n")
            f.write("LLM_API_KEY='" + key.replace("'", "\\'") + "'\n")
    print("密钥已保存到本机。请重新运行 Start-GrowAI.cmd 使配置生效。")


class Assets(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, ".js": "text/javascript",
                      ".mjs": "text/javascript", ".wasm": "application/wasm"}

    def translate_path(self, path):
        p = Path(super().translate_path(path))
        if not p.suffix and not p.exists() and p.with_suffix(".html").is_file():
            return str(p.with_suffix(".html"))
        return str(p)

    def list_directory(self, path):
        self.send_error(404)
        return None

    def log_message(self, *args):
        pass


def protect_socket(sock):
    if os.name == "nt":
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)


class LocalWeb(ThreadingHTTPServer):
    allow_reuse_address = False

    def server_bind(self):
        protect_socket(self.socket)
        super().server_bind()


def serve(no_browser):
    from uvicorn import Config, Server

    backend = ROOT / "backend"
    web = ROOT / "web"
    if not (web / "index.html").is_file() or not (backend / "app" / "main.py").is_file():
        raise ValueError("缺少应用文件，请完整解压后再启动。")
    config = settings(backend / ".env")
    for name in list(os.environ):
        if name.startswith("LLM_"):
            del os.environ[name]
    os.environ.update({k: v for k, v in config.items() if k.startswith("LLM_") and v is not None})
    os.environ.setdefault("LLM_MODEL", "deepseek-v4-pro")
    os.environ.setdefault("LLM_BASE_URL", BASE)
    os.environ["PYTHON_DOTENV_DISABLED"] = "1"
    os.environ["FRONTEND_ORIGINS"] = URL
    sys.path.insert(0, str(backend))
    try:
        from app.main import app
    except (ValueError, ImportError):
        raise ValueError("后端配置或运行环境无效，请核对 backend/.env 并确保 ZIP 已完整解压。") from None

    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as api:
        try:
            protect_socket(api)
            api.bind((HOST, 8000))
        except OSError:
            raise ValueError("无法使用本机端口 8000。请先关闭原来的 GrowAI，或检查端口是否已被其他程序占用或保留。") from None
        try:
            site = LocalWeb((HOST, 8081), partial(Assets, directory=str(web)))
        except OSError:
            raise ValueError("无法使用本机端口 8081。请先关闭原来的 GrowAI，或检查端口是否已被其他程序占用或保留。") from None
        with site:
            web_thread = threading.Thread(target=site.serve_forever, daemon=True)
            class LocalServer(Server):
                async def startup(self, sockets=None):
                    await super().startup(sockets=sockets)
                    if not self.started:
                        return
                    print(f"GrowAI 已启动：{URL}\n按 Ctrl+C 可关闭整个服务。", flush=True)
                    if not os.environ.get("LLM_API_KEY"):
                        print("本地任务和日历可以使用。启用智能体请运行 Configure-AI.cmd。", flush=True)
                    web_thread.start()
                    if not no_browser:
                        threading.Thread(target=webbrowser.open, args=(URL,), daemon=True).start()

            server = LocalServer(Config(app, host=HOST, port=8000, loop="asyncio", http="h11",
                                        ws="none", access_log=False, log_level="warning", timeout_graceful_shutdown=5))
            try:
                server.run(sockets=[api])
                if not server.started:
                    raise ValueError("后端未能启动，请检查配置和运行环境。")
            finally:
                if web_thread.is_alive():
                    site.shutdown()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("run", "configure"))
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "configure":
            configure()
        else:
            serve(args.no_browser)
    except (KeyboardInterrupt, EOFError):
        print("GrowAI 已关闭。")
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except OSError:
        print("无法读写本地文件，请将完整压缩包解压到自己可写的普通目录后重试。", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
