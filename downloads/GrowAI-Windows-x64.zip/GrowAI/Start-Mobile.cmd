@echo off
"%~dp0runtime\python\python.exe" -I -B -X utf8 "%~dp0mobile_server.py" --phone %*
if errorlevel 1 pause
