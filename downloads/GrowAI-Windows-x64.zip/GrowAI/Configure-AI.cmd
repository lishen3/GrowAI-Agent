@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0runtime\python\python.exe" goto missing
"%~dp0runtime\python\python.exe" -I -B -X utf8 "%~dp0growai_windows.py" configure
set "result=%ERRORLEVEL%"
pause
exit /b %result%
:missing
echo Please extract the entire GrowAI ZIP before configuring.
pause
exit /b 1
